a = 10


def b(x: int, y: int) -> str:
    return str(x + y)
